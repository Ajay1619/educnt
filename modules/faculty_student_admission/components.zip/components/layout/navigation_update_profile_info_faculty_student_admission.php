
<?php
include_once('../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>

<div class="form-navigation">
            <button class="btn prev-btn">Previous</button>
            <button class="btn next-btn" id="nxt_btn">Next</button>
        </div>
<script>
    $(document).ready(function() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const route = urlParams.get('route');
        const action = urlParams.get('action');
        const type = urlParams.get('type');
        let currentUrl = window.location.href;
        
        $('#nxt_btn').on('click', function(e) {
            e.preventDefault(); // Prevent default button behavior
            
            // Initialize variable for new parameters
            let params = '';
            
            // Logic to update the `params` based on the current type
            if (action === 'add' && route === 'personal') {
                if (!type || type === '') {
                    params = '?action=add&route=personal&type=personal';
                } else if (type === 'personal') {
                    params = '?action=add&route=personal&type=contact';
                } else if (type === 'contact') {
                    params = '?action=add&route=personal&type=address';
                } else if (type === 'address') {
                    // Looping back to personal (optional)
                    params = '?action=add&route=education&type=sslc';
                }
            } else {
                console.log('No matching condition for route and action');
                return;
            }
            
            // Construct the new URL by appending parameters
            let newUrl = currentUrl.split('?')[0] + params;
            
            // Redirect to the new URL with the updated parameters
            window.location.href = newUrl;
        });

    } catch (error) {
        console.error('An error occurred while processing:', error);
    }
});

// $(document).ready(function() {
//     try {
//         const urlParams = new URLSearchParams(window.location.search);
//         const route = urlParams.get('route');
//         const action = urlParams.get('action');
//         const type = urlParams.get('type');

//         $('#nxt_btn').on('click', function(e) {
//             e.preventDefault(); // Prevent default button behavior

//             // Initialize variable for new parameters
//             let params = '';

//             // Logic to update the `params` based on the current type
//             if (action === 'add' && route === 'personal') {
//                 if (!type || type === '') {
//                     params = '?action=add&route=personal&type=personal';
//                 } else if (type === 'personal') {
//                     params = '?action=add&route=personal&type=contact';
//                 } else if (type === 'contact') {
//                     params = '?action=add&route=personal&type=address';
//                 } else if (type === 'address') {
//                     params = '?action=add&route=education&type=sslc';
//                 }
//             } else if (action === 'add' && route === 'education') {
//                 if (type === 'sslc') {
//                     params = '?action=add&route=education&type=hsc';
//                 } else if (type === 'hsc') {
//                     params = '?action=add&route=education&type=diploma';
//                 } else if (type === 'diploma') {
//                     params = '?action=add&route=education&type=ug';
//                 } else if (type === 'ug') {
//                     params = '?action=add&route=education&type=pg';
//                 } else if (type === 'pg') {
//                     // If pg is the final step, you might redirect elsewhere or handle completion.
//                     params = '?action=add&route=education&type=pg'; // Modify as needed for completion
//                 }
//             } else {
//                 console.log('No matching condition for route and action');
//                 return;
//             }

//             // Construct the new URL by appending parameters
//             const newUrl = window.location.origin + window.location.pathname + params;

//             // Use history.pushState to update the URL without refreshing the page
//             history.pushState({ action, route, type }, '', newUrl);

//             // Optionally, you can update the page content here without a refresh
//             // For example, load new content based on the new parameters

//         });

//     } catch (error) {
//         console.error('An error occurred while processing:', error);
//     }
// });



        
</script>
<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}