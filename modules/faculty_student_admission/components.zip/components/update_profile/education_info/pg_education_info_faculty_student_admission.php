
<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>

<form id="faculty_student_admission_pg_details_form">
<div class="tab-content active" data-tab-content="4">
                    <h2>PG Education</h2>
                    <div class="row">
                        <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                            <div class="input-container">
                            <input type="text" id="industry_institution_name" placeholder=" " required aria-required="true">
                            <label class="input-label" for="industry_institution_name">Enter Your Institution name</label>
                        </div>
                        </div>
                        <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                            <div class="input-container">
                            <input type="text" id="industry_designation" placeholder=" " required aria-required="true">
                            <label class="input-label" for="industry_designation">Enter Your Designation</label>
                        </div>
                        </div>
                        <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                            <div class="input-container">
                            <input type="text" id="pg_passed_out_year" placeholder=" " required aria-required="true">
                            <label class="input-label" for="pg_passed_out_year">Enter Your Passed Out Year</label>
                        </div>
                        </div>
                        <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                            <div class="input-container">
                            <input type="text" id="pg_cgpa" placeholder=" " required aria-required="true">
                            <label class="input-label" for="pg_cgpa">Enter Your CGPA</label>
                        </div>
                        </div>
                        <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                            <div class="input-container">
                            <input type="text" id="pg_percentage" placeholder=" " required aria-required="true">
                            <label class="input-label" for="pg_percentage">Enter Your Percentage</label>
                        </div>
                        </div>
                    </div>
                </div>
            </form>
<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}