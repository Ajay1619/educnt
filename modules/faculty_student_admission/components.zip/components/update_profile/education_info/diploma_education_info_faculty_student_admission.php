<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>

    <form id="faculty_student_admission_diploma_details_form">
        <div class="tab-content active" data-tab-content="2">
            <h2>Diploma Education</h2>
            <div class="row">
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="diploma_institution_name" placeholder=" " required aria-required="true">
                        <label class="input-label" for="diploma_institution_name">Enter Your Institution name</label>
                    </div>
                </div>
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="diploma_specialization" placeholder=" " required aria-required="true">
                        <label class="input-label" for="diploma_specialization">Enter Your Specialization</label>
                    </div>
                </div>

                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="Martialstatus" placeholder=" " required aria-required="true">
                        <label class="input-label" for="diploma_passed_out_year">Enter Your Passed Out Year</label>
                    </div>
                </div>
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="diploma_percentage" placeholder=" " required aria-required="true">
                        <label class="input-label" for="diploma_percentage">Enter Your Percentage</label>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}
