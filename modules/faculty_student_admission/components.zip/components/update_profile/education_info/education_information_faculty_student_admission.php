
<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>

<div class="tab-nav">
    <button class="tab-btn sslc" data-tab="0">SSLC Education</button>
    <button class="tab-btn hsc" data-tab="1">HSC Education</button>
    <button class="tab-btn diploma" data-tab="2">Diploma Education</button>
    <button class="tab-btn ug" data-tab="3">UG Education</button>
    <button class="tab-btn pg" data-tab="4">PG Education</button>
</div>
    <section id="update_personal_profile">
        <div class="step-content active" data-step="1">
            <section id="info"></section>
          
        </div>
    </section>

<script src="<?= PACKAGES . '/jquery/jquery.js' ?>"></script>

<script>
(function() {
    // loadUrlBasedOnURL();
    const load_sslc_education_profile_info_form = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . ' /faculty_student_admission/components/update_profile/education_info/sslc_education_info_faculty_student_admission.php',ENT_QUOTES,'UTF-8') ?>',
                headers: {
                'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token  // Secure CSRF token
            },
                success: function (response) {
                    $('#info').html(response);
                    resolve(); // Resolve the promise
                },
                error: function (jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
                });
    });
        };
    const load_hsc_education_info_form = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . ' /faculty_student_admission/components/update_profile/education_info/hsc_education_info_faculty_student_admission.php',ENT_QUOTES,'UTF-8') ?>',
                headers: {
                'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token  // Secure CSRF token
            },
                success: function (response) {
                    $('#info').html(response);
                    resolve(); // Resolve the promise
                },
                error: function (jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
                });
    });
        };
    const load_diploma_education_info_form = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . ' /faculty_student_admission/components/update_profile/education_info/diploma_education_info_faculty_student_admission.php',ENT_QUOTES,'UTF-8') ?>',
                headers: {
                'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token  // Secure CSRF token
            },
                success: function (response) {
                    $('#info').html(response);
                    resolve(); // Resolve the promise
                },
                error: function (jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
                });
    });
        };
    const load_ug_education_info_form = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . ' /faculty_student_admission/components/update_profile/education_info/ug_education_info_faculty_student_admission.php',ENT_QUOTES,'UTF-8') ?>',
                headers: {
                'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token  // Secure CSRF token
            },
                success: function (response) {
                    $('#info').html(response);
                    resolve(); // Resolve the promise
                },
                error: function (jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
                });
    });
        };
    const load_pg_education_info_form = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES .  '/faculty_student_admission/components/update_profile/education_info/pg_education_info_faculty_student_admission.php',ENT_QUOTES,'UTF-8') ?>',
                headers: {
                'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token  // Secure CSRF token
            },
                success: function (response) {
                    $('#info').html(response);
                    resolve(); // Resolve the promise
                },
                error: function (jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
                });
    });
        };
        $(document).ready(async function() {
    try {
        // await NavigationProfileForm();
        const urlParams = new URLSearchParams(window.location.search);
        const route = urlParams.get('route');
        const action = urlParams.get('action');
        const type = urlParams.get('type');
        const tab = urlParams.get('tab');

         console.log(`Route: ${route}, Action: ${action}, Type: ${type}, tab: ${tab}`);
         $('.step.personalstep').removeClass('active');
          $('.step.educationstep').addClass('active');
          $('.step.coursestep').removeClass('active');
          $('.step.documentuploadstep').removeClass('active');

        
        // Condition to load the correct form based on URL parameters
        const loadComponentsBasedOnURL = async () => {
           
            if (action == 'add' && route == 'student' && type == 'education') {
                if (tab == 'sslc') {
                    load_sslc_education_profile_info_form();
                    $('.tab-btn.sslc').addClass('active');
                } else if (tab == 'hsc') {
                    load_hsc_education_info_form();
                    $('.tab-btn.hsc').addClass('active');
                    // $('.tab-btn.personal').addClass('active').css('background-color', 'var(--success-dark)');
                } else if (tab == 'diploma') {
                    load_diploma_education_info_form();
                    $('.tab-btn.diploma').addClass('active');
                    // $('.tab-btn.personal').addClass('active').css('background-color', 'var(--success-dark)');
                } 
                 else if (tab == 'ug') {
                    load_ug_education_info_form();
                    $('.tab-btn.ug').addClass('active');
                    // $('.tab-btn.personal').addClass('active').css('background-color', 'var(--success-dark)');
                } else if (tab == 'pg') {
                    load_pg_education_info_form();
                    $('.tab-btn.pg').addClass('active');
                }
            } else {
                console.log('No matching condition for route and action');
            }
        };

        // Call the function directly, no need for another $(document).ready
        await loadComponentsBasedOnURL();

    } catch (error) {
        console.error('An error occurred while processing:', error);
    }
});
}) ();

</script>

<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}