
<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
?>

<div class="tab-nav">
<button class="tab-btn personal" >Personal Details</button>
    <button class="tab-btn contact" >Contact Details</button>
    <button class="tab-btn parent" >Parents Details</button>
    <button class="tab-btn address" >Address Details</button>
</div>

<section id="update_personal_profile">

    <div class="step-content active" data-step="0">
        <section id="info"></section>
        <!-- <section id="contact_info"></section>
        <section id="address_info"></section> -->
    </div>
</section>


<script src="<?= PACKAGES . '/jquery/jquery.js' ?>"></script>

<script>
(function() {
    const load_student_personal_profile_info_form = () => {
    return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'GET',
                    url: '<?= htmlspecialchars( MODULES . '/faculty_student_admission/components/update_profile/profile_info/personal_profile_info_faculty_student_admission.php?action=add&route=personal&type=personal' , ENT_QUOTES, 'UTF-8') ?>',
                    headers: {
                        'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token // Secure CSRF token
                    },
                    success: function(response) {
                        $('#info').html(response);
                        resolve(); // Resolve the promise
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                        reject(); // Reject the promise
                    }
                });
            });
        };
        const load_student_contact_profile_info_form = () => {
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'GET',
                    url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/update_profile/profile_info/contact_profile_info_faculty_student_admission.php?action=add&route=personal&type=contact', ENT_QUOTES, 'UTF-8') ?>',
                    headers: {
                        'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token // Secure CSRF token // Secure CSRF token
                    },
                    success: function(response) {
                        $('#info').html(response);
                        resolve(); // Resolve the promise
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                        reject(); // Reject the promise
                    }
                });
            });
        };
        const load_student_parent_profile_info_form = () => {
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'GET',
                    url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/update_profile/profile_info/parent_profile_info_faculty_student_admission.php', ENT_QUOTES, 'UTF-8') ?>',
                    headers: {
                        'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token // Secure CSRF token // Secure CSRF token
                    },
                    success: function(response) {
                        $('#info').html(response);
                        resolve(); // Resolve the promise
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                        reject(); // Reject the promise
                    }
                });
            });
        };
        const load_student_address_profile_info_form = () => {
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'GET',
                    url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/update_profile/profile_info/address_profile_info_faculty_student_admission.php', ENT_QUOTES, 'UTF-8') ?>',
                    headers: {
                                               'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token // Secure CSRF token // Secure CSRF token
                    },
                    success: function(response) {
                        $('#info').html(response);
                        resolve(); // Resolve the promise
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                        reject(); // Reject the promise
                    }
                });
            });
        };
        const NavigationProfileForm = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/layout/navigation_update_profile_info_faculty_student_admission.php', ENT_QUOTES, 'UTF-8') ?>',
                headers: {
                   'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token
                },
                success: function(response) {
                    $('#navigation').html(response);
                    resolve(); // Resolve the promise
                },
                error: function(jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
            });
        });
    };
        
    //     $(document).ready(function() {
    //     const urlParams = new URLSearchParams(window.location.search);
    //     const tab = urlParams.get('tab'); // Get the current tab from the URL

    //     // Remove 'active' from all buttons first
    //     $('.tab-btn').removeClass('active');

    //     // Add 'active' to the corresponding button based on the tab value
    //     if (tab === 'personal') {
    //         $('.tab-btn.personal').addClass('active');
    //     } else if (tab === 'contact') {
    //         $('.tab-btn.contact').addClass('active');
    //     } else if (tab === 'address') {
    //         $('.tab-btn.address').addClass('active');
    //     }
    // });
         
        $(document).ready(async function() {
    try {
        await NavigationProfileForm();
        const urlParams = new URLSearchParams(window.location.search);
        const route = urlParams.get('route');
        const action = urlParams.get('action');
        const type = urlParams.get('type');
        const tab = urlParams.get('tab');

         console.log(`Route: ${route}, Action: ${action}, Type: ${type}, tab: ${tab}`);
        $('.tab-btn').removeClass('active');
        // Condition to load the correct form based on URL parameters
        const loadComponentsBasedOnURL = async () => {
            if (action == 'add' && route == 'student' && type == 'personal') {
                if (tab == 'personal') {
                    load_student_personal_profile_info_form();
                    $('.tab-btn.personal').addClass('active');
                } else if (tab == 'contact') {
                    load_student_contact_profile_info_form();
                    $('.tab-btn.contact').addClass('active');
                    // $('.tab-btn.personal').addClass('active').css('background-color', 'var(--success-dark)');
                } 
                 else if (tab == 'parent') {
                    load_student_parent_profile_info_form();
                    $('.tab-btn.parent').addClass('active');
                    // $('.tab-btn.personal').addClass('active').css('background-color', 'var(--success-dark)');
                } else if (tab == 'address') {
                    load_student_address_profile_info_form();
                    $('.tab-btn.address').addClass('active');
                }
            } else {
                console.log('No matching condition for route and action');
            }
        };

        // Call the function directly, no need for another $(document).ready
        await loadComponentsBasedOnURL();

    } catch (error) {
        console.error('An error occurred while processing:', error);
    }
});
}) ();


</script>
<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}