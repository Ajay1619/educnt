<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>

    <form id="faculty_student_admission_address_details_form">
        <div class="tab-content active " data-tab-content="3">
           
            
            <h2> Address Details</h2>
            <div class="row">
            <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-pincode" name="address_pincode" placeholder=" " required aria-required="true">
                        <label class="input-label" for="Pincode">Enter Your Pincode</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-house-number" name="address_house_number" placeholder=" " required aria-required="true">
                        <label class="input-label" for="House_number">Enter Your House number</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-street" name="address_street" placeholder=" " required aria-required="true">
                        <label class="input-label" for="Street">Enter Your Street</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-locality" name="address_locality" placeholder=" " required aria-required="true">
                        <label class="input-label" for="Locality">Enter Your Locality</label>
                    </div>
                </div>
                
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" name="address_city" id="address-city" placeholder=" " required aria-required="true">
                        <label class="input-label" for="City">Enter Your City</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-district" name="address_district" placeholder=" " required aria-required="true">
                        <label class="input-label" for="District">Enter Your District</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-state" name="address_state" placeholder=" " required aria-required="true">
                        <label class="input-label" for="State">Enter Your State</label>
                    </div>
                </div>
                <div class="col col-1 col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="input-container">
                        <input type="text" id="address-country" name="address_country" placeholder=" " required aria-required="true">
                        <label class="input-label" for="Country">Enter Your Country</label>
                    </div>
                </div>
            </div>
        </div>
        <input type="text" id="admission_student_existing" name="admission_student_existing" value="<?php echo $existingAdmissionValue; ?>" required aria-required="true">

<div class="form-navigation">
    <button class="btn prev-btn" type="button" id="prev_btn_address">Previous</button>
    <button class="btn next-btn" id="nxt_btn_address">Next</button>
</div>
    </form>
<script>






$(document).ready(function() {
    $('#address-pincode').on('blur', function() {
    var pincode = $('#address-pincode').val();

    if (pincode) {
        $.ajax({
            url: 'https://api.postalpincode.in/pincode/' + pincode, // Use 'in' for India. Change the country code as needed.
            method: 'GET',
            success: function(data) {
                if (data[0].Status == "Success") {
                    var place = data[0].PostOffice[0];
                    $('#address-city').val(place.Name);
                    $('#address-district').val(place.District);
                    $('#address-state').val(place.State);
                    $('#address-country').val(place.Country);

                } else {
                    showToast('warning', 'No Data Available For The Entered Pincode.');
                }
            },
            error: function() {
                $('#billing-address-details').html('<p>Invalid pincode or no data available.</p>');
            }
        });
    } else {
        $('#billing-address-details').html('<p>Please enter a pincode.</p>');
    }
});

    $('#Address-Pincode').on('blur', function() {
                    var pincode = $('#Address-Pincode').val();

                    if (pincode) {
                        $.ajax({
                            url: 'https://api.postalpincode.in/pincode/' + pincode, // Use 'in' for India. Change the country code as needed.
                            method: 'GET',
                            success: function(data) {
                                if (data[0].Status == "Success") {
                                    var place = data[0].PostOffice[0];
                                    console.log(place);
                                    $('#Address-City').val(place.Name);
                                    $('#Address-District').val(place.District);
                                    $('#Address-State').val(place.State);
                                    $('#Address-Country').val(place.Country);

                                } else {
                                    $('#address-details').html('<p>No data available for this pincode.</p>');
                                }
                            },
                            error: function() {
                                $('#address-details').html('<p>Invalid pincode or no data available.</p>');
                            }
                        });
                    } else {
                        $('#address-details').html('<p>Please enter a pincode.</p>');
                    }
                });

                const EducationProfileForm = () => {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: 'GET',
                url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/update_profile/education_info/education_information_faculty_student_admission.php', ENT_QUOTES, 'UTF-8') ?>',
                headers: {
                   'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token
                },
                success: function(response) {
                    $('#content').html(response);
                    resolve(); // Resolve the promise
                },
                error: function(jqXHR) {
                    const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                    showToast('error', message);
                    reject(); // Reject the promise
                }
            });
        });
    };
    const fetch_faculty_address_data = () => {
            $.ajax({
                type: 'GET',
                url: '<?= MODULES . '/faculty_student_admission/json/fetch_student_address_data.php' ?>',
                headers: {
                    'X-CSRF-TOKEN': '<?= $csrf_token; ?>'
                },
                success: function(response) {
                    response = JSON.parse(response);
                    if (response.code === 200) {
                        const data = response.data;
                        console.log(data);
                        $('#address-house-number').val(data.student_address_no);
                        $('#address-street').val(data.student_address_street);
                        $('#address-locality').val(data.student_address_locality);
                        $('#address-pincode').val(data.student_address_pincode);
                        $('#address-city').val(data.student_address_city);
                        $('#address-district').val(data.student_address_district);
                        $('#address-state').val(data.student_address_state);
                        $('#address-country').val(data.student_address_country);

                    } else {
                        showToast(response.status, response.message);
                    }
                },
                error: function(error) {
                    showToast('error', 'Something went wrong. Please try again later.');
                }
            });
        }
        fetch_faculty_address_data();
            // load_student_contact_profile_info_form();
            $('#prev_btn_address').on('click', function(e) {
                console.log("hi");
                const params = {
                action: 'add',
                route: 'student',
                type: 'personal',
                tab: 'contact'
            };

            // Construct the new URL with query parameters
            const queryString = `?action=${params.action}&route=${params.route}&type=${params.type}&tab=${params.tab}`;
            const newUrl = window.location.origin + window.location.pathname + queryString;
            // Use pushState to set the new URL and pass params as the state object
            window.history.pushState(params, '', newUrl);
            // loadComponentsBasedOnURL();
            // load_personal_info_components();
            });
            $('#nxt_btn_address').on('click', function(e) {
                e.preventDefault();
                const formData = new FormData($('#faculty_student_admission_address_details_form')[0]); // Corrected to reference the form
                $.ajax({
                    type: 'POST',
                    url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/ajax/address_info_update.php', ENT_QUOTES, 'UTF-8') ?>',
                    data: formData,
                    contentType: false,
                    processData: false,
                    headers: {
                        'X-CSRF-Token': '<?= $csrf_token ?>' // Secure CSRF token
                    },
                    beforeSend: function() {
                        showLoading(); // Show loading before request
                    },
                    success: function(response) {

                        response = JSON.parse(response);
                        if (response.code === 200) {
                            console.log('success');
                            showToast('success', response.message);
                            console.log(response);
                            EducationProfileForm();
                            // load_sslc_education_profile_info_form();
                            
                            params = '?action=add&route=student&type=education&tab=sslc';
                            const newUrl = window.location.origin + window.location.pathname + params;

                            // Use history.pushState to update the URL without refreshing the page
                            history.pushState({ ction: 'add',  route: 'student'   }, '', newUrl);
                            
                        } else {
                            console.log(response.message);
                            showToast(response.status, response.message);
                        }
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                    },
                    complete: function() {
                        $("#Loading").html("") // Hide loading after request completes
                    }
                });
            });

            //             const existingId = $('#existing-id').val().trim(); // Get the value of existing-id

            // $.ajax({
            //     type: 'POST',
            //     url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/json/personal_info_fetch.php', ENT_QUOTES, 'UTF-8') ?>',
            //     data: {
            //         existing_id: existingId
            //     }, // Send existing_id directly
            //     headers: {
            //         'X-CSRF-Token': '<?= $csrf_token ?>' // Secure CSRF token
            //     },

            //     success: function(response) {
            //         response = JSON.parse(response);
            //         if (response.code === 200) {
            //             console.log('Success');
            //             showToast('success', response.message);
            //             // Populate the form with the fetched data, if needed
            //         } else {
            //             console.log(response.message);
            //             showToast(response.status, response.message);
            //         }
            //     },
            //     error: function(jqXHR) {
            //         const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
            //         showToast('error', message);
            //     },
            //     complete: function() {
            //         $("#Loading").html(""); // Hide loading after completion
            //     }
            // });
        });

       
</script>

<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}
