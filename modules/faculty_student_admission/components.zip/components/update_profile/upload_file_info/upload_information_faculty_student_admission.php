<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>
<div class="tab-nav">
    <button class="tab-btn upload" data-tab="0">Document Upload</button>
</div>
<section id="update_personal_profile">
<div class="step-content active" data-step="4">
        <section id="upload_info"></section>
</div>
</section>

<script src="<?= PACKAGES . '/jquery/jquery.js' ?>"></script>

<script>
    
    const load_certificate_upload_info_form = () => {
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'GET',
                    url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/update_profile/upload_file_info/upload_files_info_faculty_student_admission.php?action=add&route=student&type=documentupload&tab=document', ENT_QUOTES, 'UTF-8') ?>',
                    headers: {
                        'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token  // Secure CSRF token // Secure CSRF token
                    },
                    success: function(response) {
                        $('#upload_info').html(response);
                        resolve(); // Resolve the promise
                    },
                    error: function(jqXHR) {
                        const message = jqXHR.status === 401 ? 'Unauthorized access. Please check your credentials.' : 'An error occurred. Please try again.';
                        showToast('error', message);
                        reject(); // Reject the promise
                    }
                });
            });
        };
    
        $(document).ready(async function () {
        try {
            const urlParams = new URLSearchParams(window.location.search);
            const route = urlParams.get('route');
            const action = urlParams.get('action');
            const type = urlParams.get('type');
            const tab = urlParams.get('tab');

            console.log(`Route: ${route}, Action: ${action}, Type: ${type}`);

            // Condition to load the correct form based on URL parameters
            if (action == 'add' && route == 'student' && type == 'documentupload' ) {
                if (tab == 'document') {
                    load_certificate_upload_info_form();
                    $('.tab-btn.upload').addClass('active');
                }                 
            } else {
                console.log('No matching condition for route and action');
            }

        } catch (error) {
            console.error('An error occurred while processing:', error);
        }
    });
</script>

<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}