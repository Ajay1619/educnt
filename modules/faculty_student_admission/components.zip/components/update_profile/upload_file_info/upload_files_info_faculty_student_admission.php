<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>
<form id="faculty_student_admission_"></form>
<div class="tab-content active" data-tab-content="0">
                    <h2>Document upload</h2>                    
                    <!-- Similar structure for each document -->
                    <div class="form-row">
                        <div class="floating-label">
                            <h2>SSLC Upload</h2>
                            <input type="file" id="sslc_upload" accept=".pdf, .doc, .docx" required>
                            <label class="placeholder" for="sslc_upload">Upload Your SSLC (PDF or DOC)</label>
                        </div>
                        <div class="file-preview">
                            <img id="sslc_icon" alt="File Icon" style="display: none; width: 50px;" />
                        </div>
                    </div>
            
                    <div class="form-row">
                        <div class="floating-label">
                            <h2>HSC Upload</h2>
                            <input type="file" id="hsc_upload" accept=".pdf, .doc, .docx" required>
                            <label class="placeholder" for="hsc_upload">Upload Your HSC (PDF or DOC)</label>
                        </div>
                        <div class="file-preview">
                            <img id="hsc_icon" alt="File Icon" style="display: none; width: 50px;" />
                        </div>
                    </div>
            
                    <div class="form-row">
                        <div class="floating-label">
                            <h2>UG Upload</h2>
                            <input type="file" id="ug_upload" accept=".pdf, .doc, .docx" required>
                            <label class="placeholder" for="ug_upload">Upload Your UG (PDF or DOC)</label>
                        </div>
                        <div class="file-preview">
                            <img id="ug_icon" alt="File Icon" style="display: none; width: 50px;" />
                        </div>
                    </div>
            
                    <div class="form-row">
                        <div class="floating-label">
                            <h2>PG Upload</h2>
                            <input type="file" id="pg_upload" accept=".pdf, .doc, .docx" required>
                            <label class="placeholder" for="pg_upload">Upload Your PG (PDF or DOC)</label>
                        </div>
                        <div class="file-preview">
                            <img id="pg_icon" alt="File Icon" style="display: none; width: 50px;" />
                        </div>
                    </div>
            
                    <div class="form-row">
                        <div class="floating-label">
                            <h2>Diploma Upload</h2>
                            <input type="file" id="diploma_upload" accept=".pdf, .doc, .docx" required>
                            <label class="placeholder" for="diploma_upload">Upload Your Diploma (PDF or DOC)</label>
                        </div>
                        <div class="file-preview">
                            <img id="diploma_icon" alt="File Icon" style="display: none; width: 50px;" />
                        </div>
                    </div>
                </div>

                <script src="<?= MODULES . '/student_interview/js/files_upload.js' ?>"></script>
<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}