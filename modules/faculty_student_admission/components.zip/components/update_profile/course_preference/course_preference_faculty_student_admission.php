<?php
include_once('../../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>
    <form id="faculty_student_admission_course_details_form">
        <div class="tab-content active" data-tab-content="1">
            <h2>Contact Details</h2>
            <div class="row">
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="1st-course" placeholder=" " required aria-required="true">
                        <label class="input-label" for="1st-course">Enter 1st course Preference </label>
                    </div>
                </div>
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="2nd-course" placeholder=" " required aria-required="true">
                        <label class="input-label" for="2nd-course">Enter 2nd course Preference</label>
                    </div>
                </div>
                <div class="col col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12  ">
                    <div class="input-container">
                        <input type="text" id="3rd-course" placeholder=" " required aria-required="true">
                        <label class="input-label" for="3rd-course">Enter 3rd course Preference</label>
                    </div>
                </div>
            </div>
        </div>
    </form>


<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}
