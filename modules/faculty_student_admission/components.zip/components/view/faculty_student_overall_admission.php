<?php
include_once('../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>
<section id="bg-card"></section>
<section id="overall-profile-table"></section>
        



    <script>
       
       const loadBgCard = () => {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        type: 'GET',
                        url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/view/bg-card.php', ENT_QUOTES, 'UTF-8') ?>',
                        beforeSend: function() {
                            showLoading();
                        },
                        headers: {
                           'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token // Secure CSRF token // Secure CSRF token
                        },
                        success: function(response) {
                            $('#bg-card').html(response);
                            resolve(); // Resolve the promise
                        },
                        error: function(jqXHR) {
                            if (jqXHR.status === 401) {
                                // Redirect to the custom 401 error page
                                window.location.href = '<?= htmlspecialchars(GLOBAL_PATH . '/components/error/401.php', ENT_QUOTES, 'UTF-8') ?>';
                            } else {
                                const message = 'An error occurred. Please try again.';
                                showToast('error', message);
                            }
                            reject(); // Reject the promise
                        },
                        complete: function() {
                        $("#Loading").html("")
                    }
                    });
                });
            };
         const overall_faculty_student_admission = () => {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        type: 'GET',
                        url: '<?= htmlspecialchars(MODULES . '/faculty_student_admission/components/view/overall_faculty_student_admission.php', ENT_QUOTES, 'UTF-8') ?>',
                        beforeSend: function() {
                            showLoading();
                        },
                        headers: {
                           'X-CSRF-Token': '<?= $csrf_token ?>' , // Secure CSRF token
                'X-Requested-Path': window.location.pathname + window.location.search// Secure CSRF token // Secure CSRF token // Secure CSRF token
                        },
                        success: function(response) {
                            $('#overall-profile-table').html(response);
                            resolve(); // Resolve the promise
                        },
                        error: function(jqXHR) {
                            if (jqXHR.status === 401) {
                                // Redirect to the custom 401 error page
                                window.location.href = '<?= htmlspecialchars(GLOBAL_PATH . '/components/error/401.php', ENT_QUOTES, 'UTF-8') ?>';
                            } else {
                                const message = 'An error occurred. Please try again.';
                                showToast('error', message);
                            }
                            reject(); // Reject the promise
                        },
                        complete: function() {
                        $("#Loading").html("")
                    }
                    });
                });
            };


        $('#profileTable').DataTable({
            scrollX: true,
            initComplete: function(settings, json) {
                $('.dt-layout-table .dt-layout-cell').css('width', '100%');
                $('.dt-scroll-headInner').css('width', '100%');
                $('.dataTable').css('width', '100%');
            }
        });

        function toggle(source) {
            checkboxes = document.getElementsByName('profileCheckbox');
            for(var i=0, n=checkboxes.length; i<n; i++) {
                checkboxes[i].checked = source.checked;
            }
        }

        $(document).ready(async function() {
        try {
            await loadBgCard();
            // await viewAchievements();
             await overall_faculty_student_admission();
            //await tableAchievements();
        } catch (error) {
            console.error('An error occurred while loading:', error);
        }
    });
    </script>
    <style>
        .row {
            display: flex;
            align-items: center;
        }
        .profile_image {
            border-radius: 50%;
            margin-right: 10px;
        }
        .designation {
            font-size: 12px;
            color: #666;
        }
        .actions a {
            margin-right: 25px;
        }
        .status-icons a {
            margin-right: 15px;
        }
        /* Center align table header and data */
        th, td {
            text-align: center;
        }
        /* Make sure icons and table content are aligned properly */
        td img {
            vertical-align: middle;
        }
    </style>

<?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}
?>
