<?php
include_once('../../../../config/sparrow.php');

// Check if the request is an AJAX request
if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') &&
    isset($_SERVER['HTTP_X_CSRF_TOKEN']) &&
    $_SERVER['REQUEST_METHOD'] == 'GET'
) {
    // Validate CSRF token
    validateCsrfToken($_SERVER['HTTP_X_CSRF_TOKEN']);
    checkPageAccess($faculty_page_access_data, $_SERVER['HTTP_X_REQUESTED_PATH']);
?>
<div class="container">
        <div class="profile_view_card">
            <!-- SVG Background -->
            <div class="svg-background">
                <img src="<?= GLOBAL_PATH.'/images/svgs/pngegg.svg' ?>" alt="SVG Background" class="svg-img">
                <button class="pdf-button">PDF</button>
                <h1 class="bg_text">Profile</h1>
            </div>
            
            <!-- Profile Picture and Name Section -->
            <div class="profile-header">
                <img src="<?= GLOBAL_PATH.'/images/svcet.png' ?>" alt="Profile Picture" class="profile-pic">
                <div class="name-designation">
                    <h1>Shiyam</h1>
                    <p class="role">Parent</p>
                </div>
            </div>

            <div class="profile_view_card">  <!-- Profile Details in 3 Columns -->
            <h2>Personal Information</h2>
            <br>
            <div class="row">
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>First Name:</strong> <div>John</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Middle Name:</strong> <div>A</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Last Name:</strong> <div>Doe</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Initial:</strong> <div>J</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Date of Birth:</strong> <div> 01/01/1990</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Age:</strong><div> 30</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Gender:</strong> <div>Male</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Blood Group:</strong> <div>O+</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Email ID:</strong> <div>john@example.com</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Official Email ID:</strong> <div>john.official@example.com</div></div>
            </div>
            <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit.svg' ?>" alt="Edit" class="edit-icon">
            </div>


            <div class="profile_view_card">  <!-- Profile Details in 3 Columns -->
            <h2>Address Details</h2>
            <br>
                <h3>Permanent Address</h3>
                <br>
            <div class="row">
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Door No.:</strong> <div>123</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Street:</strong> <div>Main St.</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Area:</strong> <div>Downtown</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>District:</strong> <div>City</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>State:</strong> <div>State</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Pincode:</strong> <div>123456</div></div>
            </div>
            <br>
            <h3>Residential Address</h3>
                <br>
            <div class="row">
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Door No.:</strong> <div>123</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Street:</strong> <div>Main St.</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Area:</strong> <div>Downtown</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>District:</strong> <div>City</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>State:</strong> <div>State</div></div>
                <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Pincode:</strong> <div>123456</div></div>
            </div>
             <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit_note.svg' ?>" alt="Edit" class="edit-icon">
            </div>

            <!-- Contact Information profile_view_card -->
            <div class="profile_view_card">
                <h2>Contact Information</h2>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Phone Number:</strong> <div>123-456-7890</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>WhatsApp Number:</strong> <div>123-456-7890</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Admission Type:</strong> <div>Regular</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Date of Admission:</strong> <div>01/09/2020</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Religion:</strong> <div>Christianity</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Community:</strong> <div>General</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Aadhar Number:</strong> <div>1234-5678-9012</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>PAN Number:</strong> <div>ABCD1234E</div></div>
                </div>
                 <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit.svg' ?>" alt="Edit" class="edit-icon">
            </div>

            <!-- Parent/Guardian Information profile_view_card -->
            <div class="profile_view_card">
                <h2>Parent/Guardian Information</h2>
                <br>
                <h3>Father’s Information</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Father’s Name:</strong> <div>Robert Doe</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Father’s Mobile Number:</strong> <div>123-456-7890</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Father’s Occupation:</strong> <div>Engineer</div></div>
                </div>
                <br>
                <h3>Mother’s Information</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Mother’s Name:</strong> <div>Jane Doe</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Mother’s Mobile Number:</strong> <div>098-765-4321</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Mother’s Occupation:</strong> <div>Teacher</div></div>
                </div>
                <br>
                <h3>Guardian’s Information</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Guardian’s Name:</strong> <div>N/A</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Guardian’s Occupation:</strong><div>N/A</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Guardian’s Mobile Number:</strong> <div>N/A</div></div>
                </div>
                 <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit.svg' ?>" alt="Edit" class="edit-icon">
            </div>

            <!-- Educational Details profile_view_card -->
            <div class="profile_view_card">
                <h2>Educational Details</h2>
                <br>
                <h3>SSLC</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>School Name:</strong> <div>ABC High School</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Board:</strong> <div>State Board</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Year of Passing:</strong><div> 2005</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Total Marks:</strong> <div>500</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Percentage:</strong> <div>85%</div></div>
                </div>
                <br>
                <h3>HSC</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>School Name:</strong> <div>XYZ College</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Board:</strong> <div>State Board</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Year of Passing:</strong> <div>2007</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Total Marks:</strong> <div>600</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Percentage:</strong> <div>90%</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Cut-off Marks:</strong> <div>95%</div></div>
                </div>
                <br>
                <h3>Diploma </h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>College Name:</strong> <div>ABC Institute</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Board:</strong> <div>State Board</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Year of Passing:</strong> <div>2009</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Total Marks:</strong> <div>550</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Percentage:</strong> <div>88%</div></div>
                </div>
                <br>
                <h3>Degree</h3>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>College Name:</strong> <div>XYZ University</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Board:</strong> <div>University Board</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Year of Passing:</strong> <div>2012</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Total Marks:</strong> <div>700</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Percentage:</strong> <div>92%</div></div>
                </div>
                 <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit.svg' ?>" alt="Edit" class="edit-icon">
            </div>

            <!-- Course & Other Preferences profile_view_card -->
            <div class="profile_view_card">
                <h2>Course & Other Preferences</h2>
                <br>
                <div class="row">
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Course Preference:</strong><div> Computer Science</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Concession (If any):</strong> <div>Yes</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Transport (Yes/No):</strong> <div>Yes</div></div>
                    <div class="col-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 detail-item"><strong>Hostel (Yes/No):</strong> <div>No</div></div>
                </div>
                 <img src="<?= GLOBAL_PATH.'/images/svgs/sidenavbar_icons/old_icons/edit.svg' ?>" alt="Edit" class="edit-icon">
            </div>
        </div>
    </div>
    <?php
} else {
    echo json_encode(['code' => 400, 'status' => 'error', 'message' => 'Invalid request.']);
    exit;
}
